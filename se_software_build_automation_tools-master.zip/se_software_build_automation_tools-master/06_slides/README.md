# 6 

## Summary

What we have learnt so far:

- Linux
- git
- Python, library manageent, virtual environment, and packaging
- CI/CD - github actions:

  - lint
  - test
  - package
  - and deploy

- tools: linters


Recommendations:

- use git for all your projects at uni
- Github is for free and you can ussually copy the examples directly into your project

## Exam

- [exam](https://docs.google.com/document/d/1cYETfRZgbu1MDf7rymMALfboD8iJuGHR/edit?usp=sharing&ouid=110356918355153803010&rtpof=true&sd=true)
